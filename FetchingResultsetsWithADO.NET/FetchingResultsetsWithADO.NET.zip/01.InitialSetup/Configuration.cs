﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _01.InitialSetup
{
    public class Configuration
    {
        public const string ConnectionString = @"Server=DESKTOP-33GNNTU\SQLEXPRESS;Database=MinionsDB;Integrated Security=True";
    }
}
